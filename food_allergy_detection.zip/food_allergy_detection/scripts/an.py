import requests

API_KEY = "684643fae5f94e6a9e83c4cd5670aa1b"  # Replace with your Spoonacular API key
recipe_name = "Pasta Carbonara"  # Example recipe
allergy_list = ["peanuts", "dairy", "gluten", "egg"]  # Replace with user's allergens

# Step 1: Get Recipe ID
search_url = f"https://api.spoonacular.com/recipes/complexSearch?query={recipe_name}&apiKey={API_KEY}"
response = requests.get(search_url).json()

if "results" in response and response["results"]:
    recipe_id = response["results"][0]["id"]
    print(f"✅ Recipe ID for '{recipe_name}': {recipe_id}")

    # Step 2: Get Ingredients for the Recipe
    ingredient_url = f"https://api.spoonacular.com/recipes/{recipe_id}/ingredientWidget.json?apiKey={API_KEY}"
    response = requests.get(ingredient_url).json()

    print("\n🔹 Ingredients List:")
    found_allergens = []
    
    for item in response["ingredients"]:
        name = item["name"]
        amount = item["amount"]["metric"]["value"]
        unit = item["amount"]["metric"]["unit"]
        print(f"- {name}: {amount} {unit}")
        
        # Check if ingredient is an allergen
        if name.lower() in allergy_list:
            found_allergens.append(name)

    # Step 3: Display Allergy Warning
    if found_allergens:
        print("\n❌ WARNING: This recipe contains allergens!")
        print("🚨 Allergic Ingredients:", ", ".join(found_allergens))
    else:
        print("\n✅ This recipe is safe for you!")

else:
    print("❌ Recipe not found.")
