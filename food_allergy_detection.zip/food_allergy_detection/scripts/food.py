import cv2
import pytesseract
import os
import requests
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk

# Set Tesseract OCR Path (For Windows Users)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Spoonacular API Key (Replace with your own key)
API_KEY = "your_api_key_here"

# Function to Extract Text from Image
def extract_text_from_image(image_path):
    try:
        image = cv2.imread(image_path)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        processed_image = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        extracted_text = pytesseract.image_to_string(processed_image)
        return extracted_text
    except Exception as e:
        return f"Error extracting text: {e}"

# Function to Detect Food Items
def detect_food_items(text):
    return [word.strip() for word in text.split("\n") if word.strip()]

# Function to Get Ingredients from Spoonacular
def get_ingredients(food_item):
    try:
        search_url = f"https://api.spoonacular.com/recipes/complexSearch?query={food_item}&apiKey={API_KEY}"
        response = requests.get(search_url).json()

        if "results" in response and response["results"]:
            recipe_id = response["results"][0]["id"]
            ingredient_url = f"https://api.spoonacular.com/recipes/{recipe_id}/ingredientWidget.json?apiKey={API_KEY}"
            ingredient_response = requests.get(ingredient_url).json()
            return [item["name"] for item in ingredient_response.get("ingredients", [])]
        return []
    except Exception as e:
        return [f"Error fetching ingredients for {food_item}: {e}"]

# Function to Check for Allergens
def check_allergens(ingredients, allergies):
    return [ingredient for ingredient in ingredients if ingredient.lower() in allergies]

# Function to Handle Image Upload
def upload_image():
    file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.webp")])
    
    if file_path:
        # Display Image
        img = Image.open(file_path)
        img = img.resize((250, 250))
        img = ImageTk.PhotoImage(img)
        image_label.config(image=img)
        image_label.image = img

        # Extract and Display Text
        extracted_text = extract_text_from_image(file_path)
        extracted_text_box.delete("1.0", tk.END)
        extracted_text_box.insert(tk.END, extracted_text)

        # Detect Food Items
        detected_foods = detect_food_items(extracted_text)
        food_listbox.delete(0, tk.END)
        for food in detected_foods:
            food_listbox.insert(tk.END, food)

        global food_items
        food_items = detected_foods  # Store globally for allergy checking

# Function to Analyze Allergy Risk
def analyze_allergy():
    user_allergies = allergy_entry.get().lower().split(",")
    user_allergies = [a.strip() for a in user_allergies]

    allergy_results_box.delete("1.0", tk.END)
    
    for food in food_items:
        ingredients = get_ingredients(food)
        allergens = check_allergens(ingredients, user_allergies)

        allergy_results_box.insert(tk.END, f"🔹 {food}: {', '.join(ingredients)}\n")
        if allergens:
            allergy_results_box.insert(tk.END, f"⚠️ Allergy Warning! Contains: {', '.join(allergens)}\n\n", "warning")
        else:
            allergy_results_box.insert(tk.END, "✅ Safe to Eat\n\n")

    allergy_results_box.tag_config("warning", foreground="red", font=("Arial", 10, "bold"))

# GUI Setup
root = tk.Tk()
root.title("Food Allergy Detection")
root.geometry("600x700")
root.configure(bg="white")

# Title
title_label = tk.Label(root, text="🍽️ Food Allergy Detector", font=("Arial", 16, "bold"), bg="white", fg="black")
title_label.pack(pady=10)

# Image Upload Section
upload_button = tk.Button(root, text="📂 Upload Menu Image", command=upload_image, font=("Arial", 12), bg="black", fg="white")
upload_button.pack()

image_label = tk.Label(root, bg="white")
image_label.pack(pady=5)

# Extracted Text Section
tk.Label(root, text="Extracted Food Items:", font=("Arial", 12, "bold"), bg="white").pack()
extracted_text_box = scrolledtext.ScrolledText(root, height=5, wrap=tk.WORD, font=("Arial", 10))
extracted_text_box.pack(padx=10, pady=5)

# Food Items List
food_listbox = tk.Listbox(root, height=5, font=("Arial", 10))
food_listbox.pack(padx=10, pady=5)

# Allergy Input Section
tk.Label(root, text="Enter Known Allergies (comma-separated):", font=("Arial", 12, "bold"), bg="white").pack()
allergy_entry = tk.Entry(root, font=("Arial", 12), width=40)
allergy_entry.pack(pady=5)

# Analyze Button
analyze_button = tk.Button(root, text="🔍 Analyze Allergy Risk", command=analyze_allergy, font=("Arial", 12), bg="red", fg="white")
analyze_button.pack(pady=5)

# Allergy Results Section
tk.Label(root, text="Allergy Detection Results:", font=("Arial", 12, "bold"), bg="white").pack()
allergy_results_box = scrolledtext.ScrolledText(root, height=10, wrap=tk.WORD, font=("Arial", 10))
allergy_results_box.pack(padx=10, pady=5)

# Run GUI
root.mainloop()
