import requests

url = "https://openchat.team/api/generate"
payload = {"model": "openchat-3.5", "messages": [{"role": "user", "content": "List ingredients for Margherita Pizza"}]}
response = requests.post(url, json=payload)
print(response.json())
