import requests
import time

API_KEY = "684643fae5f94e6a9e83c4cd5670aa1b"  # Replace with your Spoonacular API key
recipe_name = "chicken briyani"  # Change this to any recipe name

# Step 1: Search for the recipe and get the ID
search_url = f"https://api.spoonacular.com/recipes/complexSearch?query={recipe_name}&apiKey={API_KEY}"

try:
    print("🔍 Searching for recipe...")
    search_response = requests.get(search_url, timeout=10)
    search_response.raise_for_status()  # Check for errors

    search_data = search_response.json()

    if "results" in search_data and search_data["results"]:
        recipe_id = search_data["results"][0]["id"]  # Extract Recipe ID
        print(f"✅ Recipe ID for '{recipe_name}': {recipe_id}")

        # Step 2: Get Ingredients using the Recipe ID
        ingredient_url = f"https://api.spoonacular.com/recipes/{recipe_id}/ingredientWidget.json?apiKey={API_KEY}"
        time.sleep(2)  # Avoid API rate limits

        print("🛒 Fetching ingredients...")
        ingredient_response = requests.get(ingredient_url, timeout=10)
        ingredient_response.raise_for_status()

        ingredient_data = ingredient_response.json()

        print("\n🔹 Ingredients:")
        for item in ingredient_data["ingredients"]:
            name = item["name"]
            amount = item["amount"]["metric"]["value"]
            unit = item["amount"]["metric"]["unit"]
            print(f"- {name}: {amount} {unit}")

    else:
        print("❌ Recipe not found.")

except requests.exceptions.Timeout:
    print("⏳ Request Timed Out! Try again later.")
except requests.exceptions.RequestException as e:
    print(f"❌ API Request Failed: {e}")
