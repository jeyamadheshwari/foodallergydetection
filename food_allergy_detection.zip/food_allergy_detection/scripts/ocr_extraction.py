import cv2
import pytesseract
from PIL import Image
import os
import requests

# Set Tesseract OCR path (Only for Windows users)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Spoonacular API Key
API_KEY = "your_api_key_here"  # Replace with your Spoonacular API key

def extract_text_from_image(image_path):
    """Extract text from an image using Tesseract OCR."""
    try:
        image = cv2.imread(image_path)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        processed_image = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        pil_image = Image.fromarray(processed_image)
        extracted_text = pytesseract.image_to_string(pil_image)
        return extracted_text
    except Exception as e:
        print(f"Error extracting text: {e}")
        return ""

def search_food_items(text):
    """Identify potential food items from the extracted text."""
    words = text.split("\n")  # Split by lines
    food_items = [word.strip() for word in words if word.strip()]  # Remove empty lines
    return food_items

def get_ingredients(food_item):
    """Fetch ingredients of a food item using Spoonacular API."""
    try:
        search_url = f"https://api.spoonacular.com/recipes/complexSearch?query={food_item}&apiKey={API_KEY}"
        response = requests.get(search_url).json()
        
        if "results" in response and response["results"]:
            recipe_id = response["results"][0]["id"]
            ingredient_url = f"https://api.spoonacular.com/recipes/{recipe_id}/ingredientWidget.json?apiKey={API_KEY}"
            ingredient_response = requests.get(ingredient_url).json()
            
            ingredients = [item["name"] for item in ingredient_response.get("ingredients", [])]
            return ingredients
        else:
            return []
    except Exception as e:
        print(f"Error fetching ingredients for {food_item}: {e}")
        return []

def check_allergens(ingredients, allergies):
    """Check for allergens in the ingredient list."""
    allergens_found = [ingredient for ingredient in ingredients if ingredient.lower() in allergies]
    return allergens_found

if __name__ == "__main__":
    # User Input
    allergy_input = input("Enter known food allergies (comma-separated): ").lower().split(",")
    allergy_list = [allergy.strip() for allergy in allergy_input]

    # Image Path
    test_image_path = r"C:\Users\jeyama\Desktop\food_allergy_detection\data\menus\1131w-ohRNgqoJW40.webp"

    if os.path.exists(test_image_path):
        extracted_text = extract_text_from_image(test_image_path)
        print("\nExtracted Text:\n", extracted_text)

        # Identify Food Items
        food_items = search_food_items(extracted_text)
        print("\nDetected Food Items:", food_items)

        # Fetch Ingredients and Check Allergies
        for food in food_items:
            ingredients = get_ingredients(food)
            print(f"\n🔹 Ingredients for {food}: {ingredients}")

            allergens = check_allergens(ingredients, allergy_list)
            if allergens:
                print(f"⚠️ Allergy Warning! {food} contains: {', '.join(allergens)}")
            else:
                print(f"✅ {food} is safe to eat.")
    else:
        print(f"Test image not found at {test_image_path}. Please check the file path.")
